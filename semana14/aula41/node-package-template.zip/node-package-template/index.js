const countries = require("./countries")
console.log(countries)